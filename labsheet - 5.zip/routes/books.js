const express = require("express");

const router = express.Router();

let books = [
    {
        id: 1,
        title: "JavaScript Basics",
        author: "John Doe"
    },
    {
        id: 2,
        title: "Node.js Guide",
        author: "Jane Doe"
    }
];

// GET all books
router.get("/", (req, res) => {
    res.json(books);
});

// GET one book
router.get("/:id", (req, res, next) => {

    const book = books.find(
        book => book.id === Number(req.params.id)
    );

    if (!book) {
        const error = new Error("Book not found");
        error.status = 404;
        return next(error);
    }

    res.json(book);
});

// POST - Add book
router.post("/", (req, res) => {

    const { title, author } = req.body;

    if (!title || !author) {
        return res.status(400).json({
            error: "title and author are required"
        });
    }

    const newBook = {
        id: books.length + 1,
        title: title,
        author: author
    };

    books.push(newBook);

    res.status(201).json(newBook);
});

// PUT - Update book
router.put("/:id", (req, res, next) => {

    const book = books.find(
        book => book.id === Number(req.params.id)
    );

    if (!book) {
        const error = new Error("Book not found");
        error.status = 404;
        return next(error);
    }

    book.title = req.body.title || book.title;
    book.author = req.body.author || book.author;

    res.json(book);
});

// DELETE - Delete book
router.delete("/:id", (req, res, next) => {

    const index = books.findIndex(
        book => book.id === Number(req.params.id)
    );

    if (index === -1) {
        const error = new Error("Book not found");
        error.status = 404;
        return next(error);
    }

    const deletedBook = books.splice(index, 1)[0];

    res.json({
        message: "Book deleted successfully",
        book: deletedBook
    });
});

module.exports = router;