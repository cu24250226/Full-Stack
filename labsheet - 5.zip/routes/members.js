const express = require("express");

const router = express.Router();

let members = [
    {
        id: 1,
        name: "Nitin Dixit",
        email: "nitin@example.com"
    },
    {
        id: 2,
        name: "Aman",
        email: "aman@example.com"
    }
];

// GET all members
router.get("/", (req, res) => {
    res.json(members);
});

// GET one member
router.get("/:id", (req, res, next) => {

    const member = members.find(
        member => member.id === Number(req.params.id)
    );

    if (!member) {
        const error = new Error("Member not found");
        error.status = 404;
        return next(error);
    }

    res.json(member);
});

// POST - Add member
router.post("/", (req, res) => {

    const { name, email } = req.body;

    if (!name || !email) {
        return res.status(400).json({
            error: "name and email are required"
        });
    }

    const newMember = {
        id: members.length + 1,
        name: name,
        email: email
    };

    members.push(newMember);

    res.status(201).json(newMember);
});

// PUT - Update member
router.put("/:id", (req, res, next) => {

    const member = members.find(
        member => member.id === Number(req.params.id)
    );

    if (!member) {
        const error = new Error("Member not found");
        error.status = 404;
        return next(error);
    }

    member.name = req.body.name || member.name;
    member.email = req.body.email || member.email;

    res.json(member);
});

// DELETE - Delete member
router.delete("/:id", (req, res, next) => {

    const index = members.findIndex(
        member => member.id === Number(req.params.id)
    );

    if (index === -1) {
        const error = new Error("Member not found");
        error.status = 404;
        return next(error);
    }

    const deletedMember = members.splice(index, 1)[0];

    res.json({
        message: "Member deleted successfully",
        member: deletedMember
    });
});

module.exports = router;