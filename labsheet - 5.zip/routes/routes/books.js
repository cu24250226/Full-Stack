const express = require("express");

const router = express.Router();

let books = [

    {
        id: 1,
        title: "JavaScript Basics",
        author: "John Doe"
    },

    {
        id: 2,
        title: "Node.js Guide",
        author: "Jane Doe"
    }

];

// =================================
// GET ALL BOOKS
// GET /api/books
// =================================

router.get("/", (req, res) => {

    res.json(books);

});

// =================================
// GET ONE BOOK
// GET /api/books/:id
// =================================

router.get("/:id", (req, res, next) => {

    const book = books.find(
        book => book.id === Number(req.params.id)
    );

    if (!book) {

        const error = new Error("Book not found");

        error.status = 404;

        return next(error);
    }

    res.json(book);

});

// =================================
// ADD BOOK
// POST /api/books
// =================================

router.post("/", (req, res) => {

    const {
        title,
        author
    } = req.body;

    if (!title || !author) {

        return res.status(400).json({
            error: "title and author are required"
        });

    }

    const newBook = {

        id: books.length > 0
            ? Math.max(...books.map(book => book.id)) + 1
            : 1,

        title: title,

        author: author

    };

    books.push(newBook);

    res.status(201).json(newBook);

});

// =================================
// UPDATE BOOK
// PUT /api/books/:id
// =================================

router.put("/:id", (req, res, next) => {

    const book = books.find(
        book => book.id === Number(req.params.id)
    );

    if (!book) {

        const error = new Error("Book not found");

        error.status = 404;

        return next(error);

    }

    book.title = req.body.title || book.title;

    book.author = req.body.author || book.author;

    res.json(book);

});

// =================================
// DELETE BOOK
// DELETE /api/books/:id
// =================================

router.delete("/:id", (req, res, next) => {

    const index = books.findIndex(
        book => book.id === Number(req.params.id)
    );

    if (index === -1) {

        const error = new Error("Book not found");

        error.status = 404;

        return next(error);

    }

    const deletedBook = books.splice(index, 1)[0];

    res.json({

        message: "Book deleted successfully",

        book: deletedBook

    });

});

module.exports = router;