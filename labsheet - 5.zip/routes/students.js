const express = require("express");

const router = express.Router();

const students = [
    {
        id: 1,
        name: "Nitin Dixit",
        course: "B.Tech CSE"
    },
    {
        id: 2,
        name: "Rahul",
        course: "B.Tech CSE"
    }
];

// GET all students
router.get("/", (req, res) => {

    res.json(students);

});

// GET student by ID
router.get("/:id", (req, res, next) => {

    const student = students.find(
        student => student.id === Number(req.params.id)
    );

    if (!student) {

        const error = new Error("Student not found");

        error.status = 404;

        return next(error);
    }

    res.json(student);

});

module.exports = router;