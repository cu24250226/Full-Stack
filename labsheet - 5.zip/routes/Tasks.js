const express = require("express");

const router = express.Router();

let tasks = [
    {
        id: 1,
        title: "Complete Express Lab",
        completed: false
    },
    {
        id: 2,
        title: "Test API in Postman",
        completed: false
    }
];

// GET all tasks
router.get("/", (req, res) => {
    res.json(tasks);
});

// GET one task
router.get("/:id", (req, res, next) => {

    const task = tasks.find(
        task => task.id === Number(req.params.id)
    );

    if (!task) {
        const error = new Error("Task not found");
        error.status = 404;
        return next(error);
    }

    res.json(task);
});

// POST - Add task
router.post("/", (req, res) => {

    const {
        title,
        completed = false
    } = req.body;

    if (!title) {
        return res.status(400).json({
            error: "title is required"
        });
    }

    const newTask = {
        id: tasks.length + 1,
        title: title,
        completed: completed
    };

    tasks.push(newTask);

    res.status(201).json(newTask);
});

// PUT - Update task
router.put("/:id", (req, res, next) => {

    const task = tasks.find(
        task => task.id === Number(req.params.id)
    );

    if (!task) {
        const error = new Error("Task not found");
        error.status = 404;
        return next(error);
    }

    task.title = req.body.title || task.title;

    if (req.body.completed !== undefined) {
        task.completed = req.body.completed;
    }

    res.json(task);
});

// DELETE - Delete task
router.delete("/:id", (req, res, next) => {

    const index = tasks.findIndex(
        task => task.id === Number(req.params.id)
    );

    if (index === -1) {
        const error = new Error("Task not found");
        error.status = 404;
        return next(error);
    }

    const deletedTask = tasks.splice(index, 1)[0];

    res.json({
        message: "Task deleted successfully",
        task: deletedTask
    });
});

module.exports = router;