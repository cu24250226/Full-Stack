require("dotenv").config();

const express = require("express");

const studentsRouter = require("./routes/students");
const booksRouter = require("./routes/books");
const membersRouter = require("./routes/members");
const tasksRouter = require("./routes/tasks");

const app = express();

const PORT = process.env.PORT || 4000;

app.use((req, res, next) => {
    console.log(
        `[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`
    );
    next();
});

app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));
app.use(express.static("public"));
app.get("/", (req, res) => {
    res.send("Express Lab Running");
});

app.get("/about", (req, res) => {
    res.json({
        name: "Nitin Dixit",
        rollNumber: "YOUR_ROLL_NUMBER"
    });
});

app.get("/courses", (req, res) => {
    res.json([
        "Full Stack Web Development",
        "DBMS",
        "Data Structures"
    ]);
});

// POST /echo
app.post("/echo", (req, res) => {
    res.json(req.body);
});

app.get("/students/:id", (req, res) => {
    res.json({
        id: req.params.id,
        message: "Student details"
    });

});

app.get("/search", (req, res) => {
    res.json({
        name: req.query.name,
        age: req.query.age
    });
});

app.get("/products/:category/:id", (req, res) => {
    res.json({
        category: req.params.category,
        id: req.params.id
    });
});

function checkApiKey(req, res, next) {
    const apiKey = req.header("x-api-key");
    if (!apiKey) {
        return res.status(403).json({
            error: "Forbidden: x-api-key is required"
        });
    }
    next();
}
// Apply only to /admin routes
app.use("/admin", checkApiKey);
// Protected route
app.get("/admin/dashboard", (req, res) => {
    res.json({
        message: "Welcome to Admin Dashboard",
        user: "Nitin Dixit"
    });
});
app.post("/register", (req, res) => {

    const {
        name,
        email,
        password
    } = req.body;

    res.json({
        message: `Registration successful for ${name}`,
        email: email,
        passwordReceived: Boolean(password)
    });
});

app.post("/contact", (req, res) => {
    console.log("Contact Form Data:");
    console.log(req.body);
    res.json({
        message: "Thank you for contacting us!",
        data: req.body
    });
});

app.use("/api/students", studentsRouter);
app.use("/api/books", booksRouter);
app.use("/api/members", membersRouter);
app.use("/api/tasks", tasksRouter);
app.use((req, res, next) => {
    res.status(404).json({
        error: "Route not found"
    });

});
app.use((err, req, res, next) => {
    console.error("ERROR:", err);
    const status = err.status || 500;
    res.status(status).json({
        error: err.message || "Internal Server Error"
    });
});
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});