const fs = require("fs");
const name = "Nitin Dixit";
const rollNo = "38";
const course = "Full Stack Web Development";

fs.writeFile(
    "student.txt",
    `Name: ${name}\nRoll Number: ${rollNo}\n`,
    (err) => {
        if (err) {
            console.log("Error writing file:", err);
            return;
        }

        console.log("student.txt created successfully.");

        // Append course
        fs.appendFile(
            "student.txt",
            `Course: ${course}\n`,
            (err) => {
                if (err) {
                    console.log("Error appending file:", err);
                    return;
                }

                console.log("Course added successfully.");

                // Read file
                fs.readFile("student.txt", "utf8", (err, data) => {
                    if (err) {
                        console.log("Error reading file:", err);
                        return;
                    }

                    console.log("\nFile Content:");
                    console.log(data);

                    // Rename file
                    fs.rename("student.txt", "profile.txt", (err) => {
                        if (err) {
                            console.log("Error renaming file:", err);
                            return;
                        }

                        console.log("File renamed to profile.txt successfully.");
                    });
                });
            }
        );
    }
);