const http = require("http");
const url = require("url");

const students = [
    {
        id: 1,
        name: "Nitin",
        course: "B.Tech CSE"
    },
    {
        id: 2,
        name: "Rahul",
        course: "B.Tech CSE"
    },
    {
        id: 3,
        name: "Aman",
        course: "B.Tech CSE"
    }
];

const server = http.createServer((req, res) => {

    if (req.method === "GET" && req.url === "/") {

        res.writeHead(200, {
            "Content-Type": "text/html"
        });

        res.end(`
            <h1>Welcome to Node.js Server</h1>
        `);
    }

    else if (req.method === "GET" && req.url === "/students") {

        res.writeHead(200, {
            "Content-Type": "application/json"
        });

        res.end(JSON.stringify(students));
    }

    else if (
        req.method === "GET" &&
        req.url.startsWith("/search")
    ) {

        // Parse URL and query string
        const parsedUrl = url.parse(req.url, true);

        // Get keyword
        const keyword = parsedUrl.query.keyword;

        res.writeHead(200, {
            "Content-Type": "text/html"
        });

        res.end(`
            <h1>Search Result</h1>
            <p>Keyword: ${keyword || "No keyword provided"}</p>
        `);
    }

    else if (
        req.method === "GET" &&
        req.url.startsWith("/students/")
    ) {

        const id = parseInt(req.url.split("/")[2]);

        const student = students.find(
            student => student.id === id
        );

        if (student) {

            res.writeHead(200, {
                "Content-Type": "application/json"
            });

            res.end(JSON.stringify(student));

        } else {

            res.writeHead(404, {
                "Content-Type": "application/json"
            });

            res.end(JSON.stringify({
                error: "Student not found"
            }));
        }
    }

    else {

        res.writeHead(404, {
            "Content-Type": "text/html"
        });

        res.end(`
            <h1>404 - Page Not Found</h1>
        `);
    }
});

// Start server
server.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});