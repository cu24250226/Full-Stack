const sum = require("./sum");
const checkEvenOdd = require("./even-odd");

let a = 10;
let b = 20;
let number = 15;

console.log("Sum =", sum(a, b));
console.log(number, "is", checkEvenOdd(number));