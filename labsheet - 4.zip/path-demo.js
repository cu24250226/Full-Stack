const path = require("path");

// Hardcoded file path
const filePath = "/home/user/data/report.pdf";

// Directory name
console.log("Directory Name:", path.dirname(filePath));

// Base name
console.log("Base Name:", path.basename(filePath));

// Extension
console.log("Extension:", path.extname(filePath));

// Relative path
const relativePath = "./data/report.pdf";

// Absolute path
console.log("Absolute Path:", path.resolve(relativePath));
