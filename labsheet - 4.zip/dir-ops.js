const fs = require("fs");

const folder = "uploads";

// Create directory
fs.mkdir(folder, { recursive: true }, (err) => {
    if (err) {
        console.log("Error creating directory:", err);
        return;
    }

    console.log("uploads directory created.");

    // Create 3 files
    fs.writeFile(`${folder}/file1.txt`, "", (err) => {
        if (err) console.log(err);

        fs.writeFile(`${folder}/file2.txt`, "", (err) => {
            if (err) console.log(err);

            fs.writeFile(`${folder}/file3.txt`, "", (err) => {
                if (err) console.log(err);

                console.log("Three files created.");

                // Read directory
                fs.readdir(folder, (err, files) => {
                    if (err) {
                        console.log("Error reading directory:", err);
                        return;
                    }

                    console.log("\nFiles inside uploads:");
                    console.log(files);

                    // Delete one file
                    fs.unlink(`${folder}/file3.txt`, (err) => {
                        if (err) {
                            console.log("Error deleting file:", err);
                            return;
                        }

                        console.log("file3.txt deleted successfully.");
                    });
                });
            });
        });
    });
});