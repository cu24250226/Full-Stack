const fs = require("fs");

const fileName = "large-file.txt";

// Create 50 lines
let data = "";

for (let i = 1; i <= 50; i++) {
    data += `This is line number ${i}\n`;
}

// Write file
fs.writeFileSync(fileName, data);

console.log("large-file.txt created successfully.\n");

// Create read stream
const stream = fs.createReadStream(fileName, {
    encoding: "utf8"
});

// Read chunks
stream.on("data", (chunk) => {
    console.log("Chunk received.");
    console.log("Chunk size:", Buffer.byteLength(chunk), "bytes");
});

// End event
stream.on("end", () => {
    console.log("\nFinished reading the file.");
});

stream.on("error", (err) => {
    console.log("Error:", err.message);
});