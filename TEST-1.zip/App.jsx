import Counter from "./Counter.jsx";
import Todolist from "./Todolist.jsx";
import LoginToggle from "./LoginToggle.jsx";
import SearchFilter from "./SearchFilter.jsx";
import Stopwatch from "./Stopwatch.jsx";

export default function App() {
  return (
    <div>
      <Counter />
      <Todolist />
      <LoginToggle />
      <SearchFilter />
      <Stopwatch />
    </div>
  );
}