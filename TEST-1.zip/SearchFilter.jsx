import { useState } from "react";

const NAMES = [
  "Aarav", "Ananya", "Rohan", "Priya", "Kabir",
  "Sneha", "Vikram", "Meera", "Arjun", "Isha",
];

export default function SearchFilter() {
  const [query, setQuery] = useState("");

  const results = NAMES.filter((name) =>
    name.toLowerCase().includes(query.trim().toLowerCase())
  );

  return (
    <div>
      <h2>Q4. Live Search Filter</h2>
      <input
        type="text"
        value={query}
        placeholder="Search a name"
        onChange={(e) => setQuery(e.target.value)}
      />

      {results.length === 0 ? (
        <p>No results found</p>
      ) : (
        <ul>
          {results.map((name) => (
            <li key={name}>{name}</li>
          ))}
        </ul>
      )}
    </div>
  );
}