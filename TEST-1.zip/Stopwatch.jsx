import { useState, useEffect, useRef } from "react";

export default function Stopwatch() {
  const [elapsedMs, setElapsedMs] = useState(0);
  const [running, setRunning] = useState(false);
  const startRef = useRef(0);

  useEffect(() => {
    if (!running) return;

    // continue from the time already counted
    startRef.current = Date.now() - elapsedMs;

    // measure real time, so the stopwatch stays accurate
    const id = setInterval(() => {
      setElapsedMs(Date.now() - startRef.current);
    }, 100);

    // stop the old timer, so two timers never run together
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  const reset = () => {
    setRunning(false);
    setElapsedMs(0);
  };

  return (
    <div>
      <h2>Q5. Stopwatch</h2>
      <p>{(elapsedMs / 1000).toFixed(1)} s</p>
      <button onClick={() => setRunning(true)} disabled={running}>Start</button>
      <button onClick={() => setRunning(false)} disabled={!running}>Pause</button>
      <button onClick={reset}>Reset</button>
    </div>
  );
}