import { useState, useRef } from "react";

export default function TodoList() {
  const [text, setText] = useState("");
  const [items, setItems] = useState([]);
  const nextId = useRef(1);

  const addItem = () => {
    const clean = text.trim();
    if (clean === "") return;
    setItems([...items, { id: nextId.current++, label: clean }]);
    setText("");
  };

  const deleteItem = (id) => {
    setItems(items.filter((item) => item.id !== id));
  };

  return (
    <div>
      <h2>Q2. Todo List</h2>
      <input
        type="text"
        value={text}
        placeholder="Write a task"
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && addItem()}
      />
      <button onClick={addItem}>Add</button>

      <ul>
        {items.map((item) => (
          <li key={item.id}>
            {item.label}{" "}
            <button onClick={() => deleteItem(item.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}