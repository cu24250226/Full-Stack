import { useState } from "react";

export default function LoginToggle() {
  const [loggedIn, setLoggedIn] = useState(false);

  return (
    <div>
      <h2>Q3. Login Toggle</h2>
      {loggedIn ? (
        <>
          <p>Welcome! You are logged in.</p>
          <button onClick={() => setLoggedIn(false)}>Logout</button>
        </>
      ) : (
        <button onClick={() => setLoggedIn(true)}>Login</button>
      )}
    </div>
  );
}